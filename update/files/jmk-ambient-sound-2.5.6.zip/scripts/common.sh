#!/system/bin/sh
TARGET=/system/app/JMKAmbient.apk
BACKUP=/data/nemesis/backups/jmk-ambient-sound
STATE_FILE=$BACKUP/previous-state
PREVIOUS_APK=$BACKUP/JMKAmbient.previous.apk
RECIPE_FILE=/data/data/com.jmk.ambient/files/recipes.json
RECIPE_BACKUP=/data/nemesis/backups/jmk-ambient-sound-recipes
PARTY_STATE=/data/data/com.android.launcher3/files/jmk-ambient-party-mode
PKG=/data/nemesis/apps/jmk-ambient-sound
RUNTIME=/data/data/com.android.launcher3/files/jmk-ambient-runtime
REMOUNTED_RW=0

same_file() { [ -f "$1" ] && [ -f "$2" ] && cmp "$1" "$2" >/dev/null 2>&1; }
# Another model not checked yet (2.5.4, the rule in bin/ambient_party_mode.sh --model): true when the light may run here.
model_ok() { sh "${1:-$PKG/bin/ambient_party_mode.sh}" --model >/dev/null 2>&1; }
# A locked install tells the developer once per version, through the JMK MAP menu's outbox (sent when the head unit is
# online and reports are on; the menu adds the car's code, firmware and versions): this head unit's device, fingerprint
# and car model code, so that the model can be checked and turned on. Nothing else.
locked_report() {
    lr_ver=
    while read -r lr_line; do case "$lr_line" in package-version=*) lr_ver=${lr_line#package-version=} ;; esac; done < "$PKG/NEMESIS.data"
    lr_mark=$BACKUP/locked-reported
    lr_old=
    [ -r "$lr_mark" ] && read -r lr_old < "$lr_mark"
    [ -n "$lr_ver" ] && [ "$lr_old" != "$lr_ver" ] || return 0
    lr_box=/data/local/tmp/jmk-map-menu/outbox
    [ -d "$lr_box" ] || return 0
    lr_at=$(date +%s)000
    lr_detail="device $(getprop ro.product.device), fingerprint $(getprop ro.build.fingerprint), car $(getprop ro.product.vehicleinfo)"
    case "$lr_detail" in *'"'*|*'\'*) lr_detail='(properties not printable)' ;; esac
    lr_tmp=$lr_box/.jmk-ambient-sound-locked-$$.tmp
    echo "{\"kind\":\"jmk-report\",\"type\":\"install\",\"app\":\"jmk-ambient-sound\",\"ver\":\"$lr_ver\",\"msg\":\"jmk-ambient-sound $lr_ver locked (model not checked)\",\"detail\":\"$lr_detail\",\"at\":$lr_at}" > "$lr_tmp" 2>/dev/null || { rm -f "$lr_tmp"; return 0; }
    chmod 0644 "$lr_tmp"
    mv "$lr_tmp" "$lr_box/jmk-ambient-sound-locked-$lr_at.json" && echo "$lr_ver" > "$lr_mark"
    return 0
}
# A report to the developer (2.5.5) through the JMK MAP menu's outbox, sent when the head unit is online and reports are
# on: report <type> <msg> [<detail> [<log file>]]. The Java helper writes it (CrashReport in bin/miclight.dex: the JSON,
# this version, one file per message, so a repeat replaces the one still waiting). Never fails.
report() {
    [ -d /data/local/tmp/jmk-map-menu/outbox ] && [ -f "$PKG/bin/miclight.dex" ] || return 0
    # a folder of its own (mkdir claims it): a subshell's $$ is its parent's, and boot.sh may report from two at once
    rep_n=0
    while ! mkdir "/data/nemesis/jmk-ambient-sound-report-$$-$rep_n" 2>/dev/null; do
        rep_n=$((rep_n + 1))
        [ "$rep_n" -lt 10 ] || return 0
    done
    rep_work=/data/nemesis/jmk-ambient-sound-report-$$-$rep_n
    chmod 0700 "$rep_work" 2>/dev/null || true
    mkdir "$rep_work/dalvik-cache" 2>/dev/null || { rm -rf "$rep_work" 2>/dev/null || true; return 0; }
    ANDROID_DATA="$rep_work" CLASSPATH="$PKG/bin/miclight.dex" /system/bin/app_process /system/bin jmkaudioprobe.CrashReport "$@" </dev/null >/dev/null 2>&1 || true
    rm -rf "$rep_work" 2>/dev/null || true
    return 0
}
# The same without Java (2.5.5), for when the helper itself does not run: plain_report <file name> <type> <msg>, a fixed
# message (no quotes), no detail.
plain_report() {
    pr_box=/data/local/tmp/jmk-map-menu/outbox
    [ -d "$pr_box" ] || return 0
    pr_ver=
    { while read -r pr_line; do case "$pr_line" in package-version=*) pr_ver=${pr_line#package-version=} ;; esac; done < "$PKG/NEMESIS.data"; } 2>/dev/null || true
    pr_tmp=$pr_box/.jmk-ambient-sound-$1-$$.tmp
    echo "{\"kind\":\"jmk-report\",\"type\":\"$2\",\"app\":\"jmk-ambient-sound\",\"ver\":\"$pr_ver\",\"msg\":\"$3\",\"detail\":\"\",\"at\":$(date +%s)000}" > "$pr_tmp" 2>/dev/null || { rm -f "$pr_tmp"; return 0; }
    chmod 0644 "$pr_tmp" 2>/dev/null || true
    mv "$pr_tmp" "$pr_box/jmk-ambient-sound-$1.json" 2>/dev/null || rm -f "$pr_tmp"
    return 0
}
# CarPlay sound for the light (2.3.0): bin/libjmkalsa.so between /system/lib/libCarPlayAudio.so and tinyalsa, put in and
# taken out by CarPlayTap (in miclight.dex; the 4 KB shim stays on uninstall). Best effort: a refusal or an error only means the light does not follow
# CarPlay; the install or uninstall goes on. Takes effect at the next boot (CarPlay keeps its loaded copy until then).
carplay_tap() {
    tap_work=/data/nemesis/jmk-ambient-sound-tap-$$
    rm -rf "$tap_work"
    mkdir -p "$tap_work/dalvik-cache" || { plain_report "carplay-tap-$1" error "carplay-tap $1: no work dir"; return 0; }
    chmod 0700 "$tap_work"
    # its output as before; kept to see that the helper ran at all (2.5.5: one that did not start was never told)
    tap_out=$(ANDROID_DATA="$tap_work" CLASSPATH="$PKG/bin/miclight.dex" /system/bin/app_process /system/bin jmkaudioprobe.CarPlayTap "$@" </dev/null 2>&1) || true
    [ -z "$tap_out" ] || echo "$tap_out"
    rm -rf "$tap_work"
    case "$tap_out" in *'CarPlay sound tap: '*) ;; *) plain_report "carplay-tap-$1" error "carplay-tap $1: helper did not run" ;; esac
    return 0
}
begin_system_write() {
    found=0; writable=0
    while read -r dev mountpoint fs options rest; do
        [ "$mountpoint" = /system ] || continue
        found=1
        case ",$options," in *,rw,*) writable=1 ;; esac
        break
    done < /proc/mounts
    [ "$found" -eq 1 ] || { echo 'Cannot determine /system mount state' >&2; return 1; }
    if [ "$writable" -eq 0 ]; then /system/xbin/nemesis remount rw || return 1; REMOUNTED_RW=1; fi
}
end_system_write() {
    # /system stays read-write (NEMESIS leaves it so after boot): a "remount ro" that failed (EBUSY) used to fail this
    # hook, and an update then stopped half-way with the package half-removed (car 2026-11-10, ambient 2.4.3)
    REMOUNTED_RW=0
    return 0
}
stop_worker() {
    [ "$(getprop sys.boot_completed)" = 1 ] || return 0
    controller=${1:-$RUNTIME/ambient_party_mode.sh}
    # Check as UID 1000: root started from adb has no DAC override and can't see into launcher3's data.
    # No controller means nothing was ever started.
    # A running effect is remembered so postinstall can start it again after an update.
    if /system/xbin/nemesis root 1000 -c "[ -f $controller ] && TMPDIR=/data/data/com.android.launcher3/cache sh $controller --status --state-dir $PARTY_STATE" >/dev/null 2>&1; then
        mkdir -p "$BACKUP" && chmod 0700 "$BACKUP" && date +%s > "$BACKUP/restart-after-update"
    fi
    /system/xbin/nemesis root 1000 -c "[ -f $controller ] || exit 0; TMPDIR=/data/data/com.android.launcher3/cache sh $controller --stop --state-dir $PARTY_STATE"
}
# The restart after an update is done by bin/boot.sh, which NEMESIS starts as a service right after
# the update: started from a hook, `nemesis root -c --start` keeps the install waiting while the
# effect runs (the worker shell holds the root session's /dev/tty as fd 10, which mksh can't close).
install_runtime() {
    stage=$1
    # The package tree may be private to root. A root-owned, traversable staging
    # directory allows UID 1000 to copy only these two files into its own data.
    /system/xbin/nemesis root 1000 -c "set -e; r=$RUNTIME; s=$stage; [ ! -L \$r ]; mkdir -p \$r; chmod 755 \$r; cd \$r; for f in ambient_party_mode.sh miclight.dex; do cp \$s/\$f \$f.new; chmod 644 \$f.new; cmp \$s/\$f \$f.new >/dev/null; done; mv ambient_party_mode.sh.new ambient_party_mode.sh; mv miclight.dex.new miclight.dex"
}
replace_apk() {
    source_apk=$1
    temp_apk=$TARGET.pending.$$
    [ ! -e "$temp_apk" ] || return 1
    cp "$source_apk" "$temp_apk" || return 1
    chmod 0644 "$temp_apk" || { rm -f "$temp_apk"; return 1; }
    same_file "$source_apk" "$temp_apk" || { rm -f "$temp_apk"; return 1; }
    mv "$temp_apk" "$TARGET" || return 1
    sync
    same_file "$source_apk" "$TARGET"
}
