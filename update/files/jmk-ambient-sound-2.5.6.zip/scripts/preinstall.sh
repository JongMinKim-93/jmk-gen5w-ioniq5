#!/system/bin/sh
set -e
. ./scripts/common.sh
# Any head unit (2.5.4): on one these commands were not checked on, it installs locked (bin/ambient_party_mode.sh
# --model): no light command, no CarPlay sound tap, the MAP menu's screen read-only. Before, the install was refused.
if sh bin/ambient_party_mode.sh --model >/dev/null 2>&1; then
    echo 'Head unit checked for the ambient light.'
else
    echo "Other model ($(getprop ro.build.product)): installs locked, no light commands until this model is checked."
fi
# the JMK MAP menu decides whether this version may run (2.1.1+) and updates it: it goes in first. Only on a first
# install: an update has already run the old package's uninstall hooks by now (NEMESIS is not transactional), so a
# refusal here would leave it half removed. The backups folder outlives an uninstall.
if [ ! -d "$BACKUP" ] && [ ! -d /data/nemesis/apps/jmk-map-menu ] && [ ! -d /data/nemesis/packages/jmk-map-menu ]; then
    echo 'JMK 런처 메뉴(jmk-map-menu)를 먼저 설치하세요 (install jmk-map-menu first)' >&2
    exit 1
fi
[ -f app/JMKAmbient.apk ] && [ -f bin/miclight.dex ] && [ -f bin/ambient_party_mode.sh ] || { echo 'Package payload incomplete' >&2; exit 1; }
if [ -e "$TARGET" ]; then
    if ! same_file "$TARGET" app/JMKAmbient.apk && ! same_file "$TARGET" app/JMKAmbient-approved-legacy.apk; then
        echo 'Existing JMKAmbient.apk differs from the approved build; refusing replacement' >&2
        exit 1
    fi
fi
