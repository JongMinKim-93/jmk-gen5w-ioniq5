#!/system/bin/sh
set -e
. ./scripts/common.sh
[ -f app/JMKAmbient.apk ] && [ -f bin/miclight.dex ] || exit 1
# Taking over from the old package id (ambient-sound, app org.gen5w.ambientsound, up to 2.0.7): stop its worker so the
# two never fight over the light (and start ours after this install if it ran), and leave its settings where the new
# app imports them on its first start. The old package is then removed with `nemesis uninstall ambient-sound`.
OLD_CTL=/data/data/com.android.launcher3/files/ambient-sound-runtime/ambient_party_mode.sh
OLD_STATE=/data/data/com.android.launcher3/files/ambient-party-mode
OLD_FILES=/data/data/org.gen5w.ambientsound/files
MIGRATE=/data/local/tmp/jmk-ambient-migrate
if [ "$(getprop sys.boot_completed)" = 1 ]; then
    if /system/xbin/nemesis root 1000 -c "[ -f $OLD_CTL ] && TMPDIR=/data/data/com.android.launcher3/cache sh $OLD_CTL --status --state-dir $OLD_STATE" >/dev/null 2>&1; then
        mkdir -p "$BACKUP" && chmod 0700 "$BACKUP" && date +%s > "$BACKUP/restart-after-update"
        /system/xbin/nemesis root 1000 -c "TMPDIR=/data/data/com.android.launcher3/cache sh $OLD_CTL --stop --state-dir $OLD_STATE" >/dev/null 2>&1 || true
        echo 'Stopped the old ambient-sound worker.'
    fi
    # as the shell user: it owns /data/local/tmp, and the old settings files are world-readable
    /system/xbin/nemesis root 2000 -c "mkdir -p $MIGRATE; chmod 755 $MIGRATE; for f in effect.json recipes.json; do [ -r $OLD_FILES/\$f ] && cp $OLD_FILES/\$f $MIGRATE/\$f && chmod 644 $MIGRATE/\$f; done; true" >/dev/null 2>&1 || true
fi
chmod 0755 "$PKG" "$PKG/bin" "$PKG/scripts"
chmod 0644 "$PKG/bin/miclight.dex" "$PKG/bin/ambient_party_mode.sh"
[ ! -f "$PKG/bin/libjmkalsa.so" ] || chmod 0644 "$PKG/bin/libjmkalsa.so"
stage=/data/nemesis/jmk-ambient-sound-stage-$$
[ ! -e "$stage" ] || { echo 'Runtime staging path already exists' >&2; exit 1; }
mkdir "$stage"
chmod 0755 "$stage"
trap 'rm -rf "$stage"' 0
cp "$PKG/bin/ambient_party_mode.sh" "$stage/ambient_party_mode.sh"
cp "$PKG/bin/miclight.dex" "$stage/miclight.dex"
chmod 0644 "$stage/ambient_party_mode.sh" "$stage/miclight.dex"
same_file "$PKG/bin/ambient_party_mode.sh" "$stage/ambient_party_mode.sh"
same_file "$PKG/bin/miclight.dex" "$stage/miclight.dex"
mkdir -p "$BACKUP"
chmod 0700 "$BACKUP"
if [ -f "$STATE_FILE" ]; then
    state=$(cat "$STATE_FILE")
    case "$state" in present) [ -f "$PREVIOUS_APK" ] || exit 1 ;; absent) ;; *) exit 1 ;; esac
else
    state_new=$BACKUP/previous-state.new.$$
    if [ -f "$TARGET" ]; then
        previous_new=$BACKUP/JMKAmbient.previous.new.$$
        cp "$TARGET" "$previous_new"
        chmod 0600 "$previous_new"
        same_file "$TARGET" "$previous_new" || exit 1
        mv "$previous_new" "$PREVIOUS_APK"
        echo present > "$state_new"
    else
        echo absent > "$state_new"
    fi
    chmod 0600 "$state_new"
    mv "$state_new" "$STATE_FILE"
fi
stop_worker "$stage/ambient_party_mode.sh" || { echo 'Could not stop the ambient worker; APK left unchanged' >&2; exit 1; }
install_runtime "$stage" || { echo 'Could not stage the system-UID runtime; APK left unchanged' >&2; exit 1; }
begin_system_write
trap 'end_system_write; rm -rf "$stage"' 0
replace_apk app/JMKAmbient.apk
# another model not checked yet (2.5.4): installed locked, so no CarPlay sound tap either (nothing to feed)
locked=0
model_ok "$stage/ambient_party_mode.sh" || locked=1
if [ "$locked" -eq 0 ]; then
    carplay_tap install "$PKG/bin/libjmkalsa.so" "$BACKUP/carplay"
else
    echo "Locked on this model ($(getprop ro.build.product)): no light commands, no CarPlay sound tap, until it is checked."
fi
end_system_write
rm -rf "$stage"
trap - 0
if [ "$(getprop sys.boot_completed)" = 1 ]; then
    # This firmware may retain a stale cache after replacing a system APK.
    # Loading a class via dalvikvm intentionally exits with no-main error.
    /system/xbin/nemesis root 1000 -c '/system/bin/dalvikvm -cp /system/app/JMKAmbient.apk jmkaudioprobe.CallReceiver' >/dev/null 2>&1 || true
    count=0
    while [ "$count" -lt 10 ]; do
        if /system/bin/pm path com.jmk.ambient 2>/dev/null | grep -q 'package:/system/app/JMKAmbient.apk'; then
            echo 'Ambient Sound package registered.'
            break
        fi
        sleep 1
        count=$((count + 1))
    done
    if [ "$count" -ge 10 ]; then
        echo 'APK installed; PackageManager has not registered it yet. A reboot may be required.' >&2
        report install "package not registered (reboot needed)"   # (2.5.5) no call light until then
    fi
    if [ -f /data/local/gen5w-home/tiles.json ] && [ -f home-tiles/installer.jar ]; then
        if CLASSPATH="$PWD/home-tiles/installer.jar" /system/bin/app_process \
            /system/bin InstallTiles /data/local/gen5w-home "$PWD/home-tiles" ambient_sound; then
            /system/bin/am force-stop com.hkmc.system.app.homesetting || echo 'Could not stop the home editor.' >&2
            /system/bin/am force-stop com.android.launcher3 || echo 'Could not stop the home launcher.' >&2
            if ! /system/bin/am start -a android.intent.action.MAIN \
                -c android.intent.category.HOME -n com.android.launcher3/.view.Launcher; then
                echo 'Could not restart the home launcher.' >&2
            fi
        else
            echo 'Home tile integration failed; package remains installed.' >&2
        fi
    fi
fi
# a locked install tells the developer once per version (this head unit's model, for checking it)
[ "$locked" -eq 0 ] || locked_report
exit 0
