#!/system/bin/sh
# Refuses to install next to another USB Wi-Fi package, and picks the mode: "locked" on a kernel or library its driver
# and patch were not made for (1.3.6: installs, does nothing), "client" on a car with the stock Wi-Fi module (the dongle only joins the phone hotspot, nothing stock is
# patched), "emulate" on a chipless car (the dongle passes as the stock module).
. ./scripts/common.sh
log "preinstall jmk-wifi"
for old in jmk.usbwifi usbwifi.hotspot; do
    if [ -d /data/nemesis/apps/$old ] || [ -d /data/nemesis/packages/$old ]; then
        log "FAIL: uninstall $old first (it runs its own driver and hotspot). Its saved networks are imported."
        sh_report preinstall-old-usbwifi "$old is installed"
        exit 1
    fi
done
# the JMK MAP menu is its screen (networks, hotspot) and its updater: it goes in first (the USB bundle's order). Only
# on a first install: an update has already run the old preuninstall (daemon stopped, stock library back), so a
# refusal here would leave the car without its Wi-Fi. $STORE (saved networks, mode) outlives an uninstall.
if [ ! -d $STORE ] && [ ! -d /data/nemesis/apps/jmk-map-menu ] && [ ! -d /data/nemesis/packages/jmk-map-menu ]; then
    log "FAIL: JMK 맵핑퀵메뉴(jmk-map-menu)를 먼저 설치하세요 (install jmk-map-menu first)"
    sh_report preinstall-no-map "jmk-map-menu is not installed"
    exit 1
fi
# another Wi-Fi app (1.3.4): both would drive the same hotspot. Only on a first install (an update has run the old
# preuninstall already, a refusal now would leave the car without its Wi-Fi); the MAP menu and the USB stick skip us
# there already, this covers a zip installed by hand.
if [ ! -f $INSTALLED ] && [ ! -d /data/nemesis/apps/jmk-wifi ] && [ ! -d /data/nemesis/packages/jmk-wifi ] && other=$(other_wifi); then
    log "FAIL: another Wi-Fi app is installed: $other. Keep it and skip the JMK Wi-Fi Driver, or uninstall it first (다른 Wi-Fi 앱이 설치되어 있습니다)"
    sh_report preinstall-other-wifi "$other"
    exit 1
fi
# Another model (1.3.6): it installs, locked where its driver or library does not fit. Locked = the driver is never
# loaded (a module for another kernel could hang or reboot the head unit), nothing stock is patched, the daemon does not
# run; the MAP menu shows "이 차종 미지원". The install used to be refused here.
locked=
read -r rel < /proc/sys/kernel/osrelease
[ "$rel" = 3.18.24-tcc ] || locked="kernel $rel, the driver is built for 3.18.24-tcc"

# The module shows only while the stock Wi-Fi is on (or its chip is powered), so once seen, client mode stays.
mode=
if [ -n "$locked" ]; then
    mode=locked
    seen=$(stock_module) || seen="no stock Wi-Fi module seen"
elif seen=$(stock_module); then
    mode=client
else
    seen="no stock Wi-Fi module seen"
    [ -f $MODE_FILE ] && read -r mode < $MODE_FILE
    [ "$mode" = client ] && seen="$seen (client mode kept from an earlier install)" || mode=emulate
fi
if [ $mode = emulate ]; then
    cur=$(md5of $LIB)
    case "$cur" in
        $STOCK_MD5|$PATCHED_MD5) log "libhardware_legacy.so $cur: ok" ;;
        *) mode=locked; locked="$LIB is $cur, neither the NEEV.KOR 260902 stock file nor our patched one" ;;
    esac
fi
mkdir -p $STORE && chmod 0700 $STORE
echo $mode > $MODE_FILE
if [ -n "$locked" ]; then echo "$locked" > $LOCKED_FILE; else rm -f $LOCKED_FILE; fi
{ echo "$(date) jmk-wifi preinstall: mode $mode ($seen)"; hw_report; } > $HW_FILE 2>&1
chmod 0644 $HW_FILE
if [ $mode = locked ]; then
    log "LOCKED on this model: $locked ($seen). Installs, but the driver is not loaded and nothing stock is patched (이 차종 미지원)."
elif [ $mode = client ]; then
    log "mode client: $seen. The stock Wi-Fi module keeps the hotspot; the dongle only joins the phone hotspot (internet, updates, wireless adb). Nothing stock is patched."
else
    log "mode emulate: $seen. The dongle passes as the stock Wi-Fi module."
fi
exit 0
