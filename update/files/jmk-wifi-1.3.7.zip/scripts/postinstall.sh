#!/system/bin/sh
# 1) the saved networks of jmk.usbwifi (its uninstall leaves them in its backups folder), once;
# 2) patch P2 into libhardware_legacy.so (stock copy kept for the uninstall), "emulate" mode only ("locked", 1.3.6:
#    another model, nothing stock is touched and nothing loads);
# 3) the old package's AP data goes, so aa.usbwifi asks the stock Wi-Fi stack.
# Driver and daemon start from [service.0]; the driver only at boot (never rmmod a loaded 88x2bu).
. ./scripts/common.sh
log "postinstall jmk-wifi"
[ -f bin/jmkwifi.dex ] && [ -f bin/88x2bu.ko ] && [ -f bin/p2.bin ] || { log "FAIL: package files missing"; sh_report postinstall-files-missing "bin: $(ls bin 2>&1)"; exit 1; }
chmod 0755 "$PKG" "$PKG/bin" "$PKG/svc" "$PKG/scripts" 2>/dev/null
chmod 0644 "$PKG/bin/jmkwifi.dex" "$PKG/bin/88x2bu.ko" "$PKG/bin/p2.bin" 2>/dev/null
chmod 0755 "$PKG/bin/jmkiw" 2>/dev/null
mkdir -p $STORE $BACKUP
chmod 0700 $STORE $BACKUP
: > $INSTALLED   # 1.3.4: an update's preinstall knows it is one

# 1) networks
if [ ! -f $STORE/networks ]; then
    mkdir -p $STORE/import
    chmod 0700 $STORE/import
    for src in /data/nemesis/apps/jmk.usbwifi/config /data/nemesis/packages/jmk.usbwifi/config /data/nemesis/backups/jmk.usbwifi; do
        for f in hotspot.conf saved_sta.conf; do
            if [ -f $src/$f ] && [ ! -f $STORE/import/$f ]; then
                cp $src/$f $STORE/import/$f && chmod 0600 $STORE/import/$f && log "import: $src/$f"
            fi
        done
    done
fi

# 2) libhardware_legacy.so: patched for "emulate"; in "client" mode (stock Wi-Fi module) the stock file, also when an
# earlier install patched it
mode=
[ -f $MODE_FILE ] && read -r mode < $MODE_FILE
cur=$(md5of $LIB)
if [ "$mode" = locked ]; then   # 1.3.6: another model, nothing stock is touched
    log "locked on this model: $LIB left as it is ($cur)"
elif [ "$mode" = client ]; then
    if [ "$cur" != $PATCHED_MD5 ]; then
        log "client mode: $LIB left as it is ($cur)"
    elif [ "$(md5of $BACKUP/libhardware_legacy.so)" = $STOCK_MD5 ] && swap_lib $BACKUP/libhardware_legacy.so \
            && [ "$(md5of $LIB)" = $STOCK_MD5 ]; then
        log "client mode: stock libhardware_legacy.so restored (takes effect at the next boot)"
    else
        log "FAIL: client mode needs the stock $LIB back and the restore failed; uninstall and reinstall"
        sh_report postinstall-client-restore "lib $cur, now $(md5of $LIB), backup $(md5of $BACKUP/libhardware_legacy.so), $(sysinfo)"
        exit 1
    fi
elif [ "$cur" = $PATCHED_MD5 ]; then
    log "libhardware_legacy.so already patched"
elif [ "$cur" = $STOCK_MD5 ]; then
    if [ "$(md5of $BACKUP/libhardware_legacy.so)" != $STOCK_MD5 ]; then
        cp $LIB $BACKUP/libhardware_legacy.so
        [ "$(md5of $BACKUP/libhardware_legacy.so)" = $STOCK_MD5 ] || { log "FAIL: backup of the stock library"; sh_report postinstall-backup "backup $(md5of $BACKUP/libhardware_legacy.so), df $(df /data 2>&1)"; exit 1; }
    fi
    rm -f $BACKUP/patched.so
    cp $BACKUP/libhardware_legacy.so $BACKUP/patched.so
    dd if=bin/p2.bin of=$BACKUP/patched.so bs=1 seek=$P2_OFFSET count=4 conv=notrunc >/dev/null 2>&1
    if [ "$(md5of $BACKUP/patched.so)" != $PATCHED_MD5 ]; then
        # a dd without conv=notrunc: build the file from three pieces
        rm -f $BACKUP/patched.so $BACKUP/tail.bin
        dd if=$BACKUP/libhardware_legacy.so of=$BACKUP/patched.so bs=1 count=$P2_OFFSET >/dev/null 2>&1
        dd if=$BACKUP/libhardware_legacy.so of=$BACKUP/tail.bin bs=1 skip=$((P2_OFFSET + 4)) >/dev/null 2>&1
        cat bin/p2.bin $BACKUP/tail.bin >> $BACKUP/patched.so
        rm -f $BACKUP/tail.bin
    fi
    [ "$(md5of $BACKUP/patched.so)" = $PATCHED_MD5 ] || { log "FAIL: patched copy is $(md5of $BACKUP/patched.so)"; sh_report postinstall-patch-md5 "patched copy $(md5of $BACKUP/patched.so), p2.bin $(md5of bin/p2.bin), backup $(md5of $BACKUP/libhardware_legacy.so), df $(df /data 2>&1)"; rm -f $BACKUP/patched.so; exit 1; }
    swap_lib $BACKUP/patched.so || { log "FAIL: could not replace $LIB"; sh_report postinstall-swap "lib now $(md5of $LIB), $(sysinfo)"; exit 1; }
    rm -f $BACKUP/patched.so
    if [ "$(md5of $LIB)" != $PATCHED_MD5 ]; then
        log "FAIL: installed library is $(md5of $LIB), putting the stock one back"
        sh_report postinstall-installed-md5 "installed $(md5of $LIB), $(sysinfo)"
        swap_lib $BACKUP/libhardware_legacy.so
        exit 1
    fi
    log "libhardware_legacy.so patched (stock copy in $BACKUP)"
else
    log "FAIL: $LIB is $cur"; sh_report postinstall-unknown-lib "lib $cur, mode $mode"; exit 1
fi

# 3) the old package's AP data
rm -f /data/local/tmp/usbwifi_hotspot/aa_ap.conf

if [ "$mode" = locked ]; then
    log "installed LOCKED: the driver is not loaded on this model and the MAP menu shows 이 차종 미지원"
    locked_report
    exit 0
fi
case "$(getprop sys.boot_completed)" in
    1) log "installed ($mode mode): reboot the head unit (NEMESIS Manager > Reboot head unit) to load the driver and the library" ;;
esac
exit 0
