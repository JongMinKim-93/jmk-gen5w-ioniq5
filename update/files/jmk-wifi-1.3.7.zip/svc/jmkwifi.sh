#!/system/bin/sh
# NEMESIS service (root): our 88x2bu driver, then the JMK Wi-Fi daemon (jmkwifi.WifiDaemon).
# The driver goes in first and as early as possible: its usbfs block must be in place before Android's USB host
# service sees the dongle (else the stock Android Auto service probes it as a phone). Port names: wlan0 for the stock
# Wi-Fi stack's hotspot, rtwlan0 for our client (usb.mode lets adb in on rtwlan* only).
# Never rmmod it (that rebooted the head unit) and never call it bcmdhd (the stock stack rmmods that name).
# After an update started from adb this runs as root without capabilities: insmod is then impossible, and the
# daemon keeps what the previous one left running until the next boot.
# (mksh: single-digit fds only; no sed/head/tail on this firmware)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
PKG=/data/nemesis/apps/jmk-wifi
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-wifi
DIR=/data/local/tmp/jmk-wifi
ARGS='ifname=wlan%d if2name=rtwlan%d rtw_country_code=KR rtw_power_mgnt=0 rtw_ips_mode=0 rtw_enusbss=0 rtw_en_napi=0 rtw_en_gro=0'
# "client" mode (the preinstall saw a stock Wi-Fi module): wlan0 belongs to the stock module, so both of our ports are
# rtwlan (the jmk.usbwifi names) and the daemon only runs the phone-hotspot client
mode=
[ -f /data/nemesis/jmk-wifi/mode ] && read -r mode < /data/nemesis/jmk-wifi/mode
[ "$mode" = client ] && ARGS="ifname=rtwlan%d ${ARGS#ifname=wlan%d }"

# "locked" (1.3.6, the preinstall decided: another model whose kernel or library does not fit): never insmod there, no
# daemon; only the status, so that the MAP menu shows 이 차종 미지원 (pid= empty: not running)
if [ "$mode" = locked ]; then
    why=
    [ -f /data/nemesis/jmk-wifi/locked ] && read -r why < /data/nemesis/jmk-wifi/locked
    if mkdir -p "$DIR" 2>/dev/null; then chmod 0755 "$DIR"; else /system/xbin/nemesis root 2000 -c "mkdir -p $DIR; chmod 0777 $DIR" </dev/null >/dev/null 2>&1; fi
    rm -f "$DIR/status.new"
    { echo "mode=locked"; echo "locked=$why"; echo "pid="; } > "$DIR/status.new" && chmod 0644 "$DIR/status.new" && mv "$DIR/status.new" "$DIR/status"
    echo "locked: no driver on this model ($why)" > "$DIR/driver.txt"
    exit 0
fi

loaded=
err=
while read -r name rest; do
    [ "$name" = 88x2bu ] && loaded=1
done < /proc/modules
if [ -z "$loaded" ]; then
    err=$(insmod "$PKG/bin/88x2bu.ko" $ARGS 2>&1)   # 1.3.7: its error text goes into driver.txt (the daemon's report)
    rc=$?
else
    rc=loaded
fi
read -r up idle < /proc/uptime

# status and logs: root's dir, readable by all (0755), so nobody can swap a log for a symlink; requests from the menu
# app go into req/ (1777). /data/local/tmp is 0771 shell:shell after boot, and root without capabilities can't create
# in it, so ask the shell user then (that dir then stays the shell's, 0777).
if mkdir -p "$DIR" 2>/dev/null; then
    chmod 0755 "$DIR"
else
    /system/xbin/nemesis root 2000 -c "mkdir -p $DIR; chmod 0777 $DIR" </dev/null >/dev/null 2>&1
fi
mkdir -p "$DIR/req" 2>/dev/null && chmod 1777 "$DIR/req"
echo "uptime $up: insmod $rc (mode ${mode:-emulate})" > "$DIR/driver.txt"
case "$rc" in 0|loaded) ;; *) [ -n "$err" ] && echo "insmod error: $err" >> "$DIR/driver.txt" ;; esac

if [ -f "$DIR/daemon.pid" ]; then
    read -r old < "$DIR/daemon.pid" || old=
    case "$old" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkwifi.WifiDaemon "/proc/$old/cmdline" 2>/dev/null && kill "$old" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
fi
mkdir -p "$PKG/var/dalvik-cache"
[ -f "$DIR/daemon.log" ] && mv "$DIR/daemon.log" "$DIR/daemon.log.old"
echo $$ > "$DIR/daemon.pid"
chmod 0644 "$DIR/daemon.pid"
ANDROID_DATA="$PKG/var" CLASSPATH="$PKG/bin/jmkwifi.dex" exec /system/bin/app_process /system/bin jmkwifi.WifiDaemon \
    </dev/null >>"$DIR/daemon.log" 2>&1
