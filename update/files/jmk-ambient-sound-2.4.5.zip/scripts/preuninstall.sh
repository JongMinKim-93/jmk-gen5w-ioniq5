#!/system/bin/sh
set -e
. ./scripts/common.sh
# an update that stopped half-way may have taken the state and the app file already (2.4.4): carry on from there
[ -f "$STATE_FILE" ] || { [ ! -f "$TARGET" ] && mkdir -p "$BACKUP" && echo absent > "$STATE_FILE"; } || { echo 'No installation backup state; leaving APK untouched' >&2; exit 1; }
state=$(cat "$STATE_FILE")
case "$state" in present) [ -f "$PREVIOUS_APK" ] || exit 1 ;; absent) ;; *) exit 1 ;; esac
same_file "$TARGET" app/JMKAmbient.apk || [ ! -f "$TARGET" ] || { echo 'Installed APK changed; leaving it untouched' >&2; exit 1; }
stop_worker || { echo 'Could not stop the ambient worker; leaving APK untouched' >&2; exit 1; }
if [ -r "$RECIPE_FILE" ]; then
    mkdir -p "$RECIPE_BACKUP"
    chmod 0700 "$RECIPE_BACKUP"
    recipe_copy=$RECIPE_BACKUP/recipes-$(date +%Y%m%d-%H%M%S)-$$.json
    cp "$RECIPE_FILE" "$recipe_copy"
    chmod 0600 "$recipe_copy"
    same_file "$RECIPE_FILE" "$recipe_copy" || exit 1
    echo "Recipe backup: $recipe_copy"
fi
begin_system_write
trap 'end_system_write' 0
# the stock CarPlay library name back (exact original bytes; the shim file stays). Only here, after every check that
# can stop this hook: a stopped uninstall or update keeps the package, so it keeps its tap too. Before 2.4.5 this ran
# first and such a stop left the package without it (car 2026-11-11); bin/boot.sh now also puts a missing tap back.
carplay_tap uninstall "$BACKUP/carplay"
if [ "$state" = present ]; then replace_apk "$PREVIOUS_APK"; else rm -f "$TARGET"; sync; fi
end_system_write
trap - 0
if [ "$state" = present ] && [ "$(getprop sys.boot_completed)" = 1 ]; then
    # Restore the old APK's Dalvik cache as well as its bytes. Loading a
    # class through dalvikvm intentionally exits with a no-main error.
    /system/xbin/nemesis root 1000 -c '/system/bin/dalvikvm -cp /system/app/JMKAmbient.apk jmkaudioprobe.CallReceiver' >/dev/null 2>&1 || true
fi
if same_file "$RUNTIME/ambient_party_mode.sh" "$PKG/bin/ambient_party_mode.sh" && same_file "$RUNTIME/miclight.dex" "$PKG/bin/miclight.dex"; then
    /system/xbin/nemesis root 1000 -c "rm -f $RUNTIME/ambient_party_mode.sh $RUNTIME/miclight.dex; rmdir $RUNTIME 2>/dev/null || true" || echo 'Runtime cleanup did not complete.' >&2
else
    echo 'Runtime files differ from the package; leaving them untouched.' >&2
fi
rm -f "$STATE_FILE"
echo 'Recipes remain in app data and a readable copy was backed up when available.'
