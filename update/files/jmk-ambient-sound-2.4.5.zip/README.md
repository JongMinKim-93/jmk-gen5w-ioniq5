# Ambient Sound NEMESIS package

This package contains the Android editor and sound-reactive lighting worker. Version 1.1.0 adds `--source media|mic|auto`: `media` reads Android's output mix through the Visualizer effect (session 0) instead of the microphone; `auto` uses media and opens the microphone only while media is digitally silent (for example FM/AM radio, which is mixed outside Android). The Korean NEEV `wp_daudioplus_neev_kr` 260902 fingerprint is accepted by the install guard (ABI checked offline, lighting untested). Recipes contain frequency bands, factory-palette colors and FFT **power** multipliers. The editor can add, remove, rename and select recipes. Start and Stop are inside the editor; stopping requests brightness 1 and keeps the last color. The worker does not save microphone audio.

## Scope and installation

This package is guarded for the observed `wp_daudioplus_neev23se_us` firmware fingerprint `ecohmc/wp_daudioplus_ecohmc_us/wp_daudioplus_ecohmc_us:4.4.2/KVT49L/eng.vmadmin.20260507.094910:user/dev-keys`. It also recognizes the workspace's `wp_daudioplus_neev_ca` QEMU guest with the exact `eng.vmadmin.20260206.061258` fingerprint and the QEMU virtio platform device. The emulator profile validates installation and UI only; it does not establish physical audio or lighting behavior. It uses the existing NEMESIS channel and the existing OEM launcher package. It is not a firmware image and does not install NEMESIS. Different firmware needs a new ABI and installation verification.

The package has a launchable shell app and uses hooks to place the APK at `/system/app/JMKAmbient.apk`: normal `pm install` was rejected on the observed unit. On install the hook stops the managed ambient worker, saves any approved previous APK, preserves the original `/system` mount state, verifies the copy, and requests PackageManager registration. If PackageManager has not registered the APK, a reboot may be needed. The hook refuses to overwrite a different existing APK unless the exact approved legacy APK is included at build time. The NEMESIS package manager can record a package before `postinstall` succeeds, so inspect the install result and logs; a failed hook is not an atomic rollback of NEMESIS's registry. On the observed physical unit, NEMESIS installed package revisions via both CLI and USB; a package-added Ambient Sound tile was present in the launcher settings and the owner reported the launcher integration worked.

Copy the ZIP to the unit, inspect it, then install using the existing NEMESIS interface:

```sh
nemesis pkg-info /path/to/ambient-sound-1.0.0.zip
nemesis install /path/to/ambient-sound-1.0.0.zip
nemesis pkg-launch jmk-ambient-sound
```

For USB installation, extract `dist/jmk-ambient-sound-usb.zip` at the drive root; its `NEMESIS.data` points to the nested package ZIP. The USB handler recognizes that descriptor automatically; Manager's separate **Run USB NEMESIS.sh** action requires a `NEMESIS.sh` file, which this archive does not contain. On the observed unit, a prompt timed out once, while later USB installs succeeded. When the package was already registered, that unit's USB handler prompted for uninstall first; the CLI supports the `--update` path below.

For a later version with the same id, NEMESIS requires `nemesis install --update ...`. Its update process invokes the old package's uninstall hooks **before** the new preinstall; it is not transactional. Review the target and backups first. Manager can also launch the package. When Android is running and the configurable launcher settings exist, the postinstall hook adds the `ambient_mic` activity tile and its icons. Existing tile IDs are left unchanged, including user edits. Tile integration failure does not fail installation. After successful integration, the hook stops the home editor and restarts the launcher so they reload the settings; this happens even when the tile already exists. Stop other long-running launcher tile commands first because their job tracking is held in memory. The tile and icons are not automatically removed on uninstall. The launcher settings updater may require its baseline to be reconciled after this external change.

The tile hook runs only when `sys.boot_completed` is `1` and `/data/local/gen5w-home/tiles.json` exists as a file. Otherwise the package installs without adding a tile. The file is a configuration check; it does not prove the launcher patches are installed or that the home editor has room for another tile. If Android was down during installation, rerun the hook after it starts or reinstall the package.

The package installs a copy of its script and DEX into the system-owned, persistent `/data/data/com.android.launcher3/files/jmk-ambient-runtime/` directory. This avoids depending on temporary files or on whether NEMESIS's root-owned package directory is traversable by UID 1000. The packaged GUI uses that script when present. It shares the existing launcher-owned worker state so the party and sound modes cannot run simultaneously. Audio processing and Binder calls run as UID 1000 through NEMESIS; its FFT is Java on the CPU, not a hardware-accelerated FFT. The GUI and worker use the launcher's private state/cache directories, so the existing `com.android.launcher3` application must have initialized them.

## Recipes and removal

Recipes are JSON in `/data/data/com.jmk.ambient/files/recipes.json`. They are not included in this ZIP, and install/update does not replace them. The file is world-readable to allow the system-UID worker to read it; it contains no audio. Before uninstall, the hook copies the recipe JSON to `/data/nemesis/backups/jmk-ambient-sound-recipes/` when readable, stops the worker, and restores the previous APK or removes the packaged one. It refuses to overwrite an APK that changed after installation. The NEMESIS manager may continue removing package files even if an uninstall hook fails; inspect its output and backups. App data retention after removing a system APK and rebooting depends on PackageManager behavior, so keep the backup. Uninstall does not edit a launcher tile; remove or retarget it separately if no previous app is restored.

## Files and provenance

- `app/JMKAmbient.apk` and `bin/miclight.dex`: generated from the project's `build/` directory when creating a ZIP.
- `app/JMKAmbient-approved-legacy.apk`: optional untracked copy of the exact previously installed editor, used only to recognize and safely back up that app. Supply it with `--approved-legacy PATH` or place it at this path. If absent, replacing a different existing APK is refused. The builder checks that this APK and the new one have the same signing certificate.
- `source/` in the ZIP: canonical top-level Java, manifest, and build script, copied at packaging time. The signing keystore is **not** in Git or the package; preserve the local `build/debug.keystore` to sign updates with the same key.
- `home-tiles/`: tile definition, artwork, and the DEX installer built from the configurable launcher project's `tools/nemesis-tiles/` helper.
- Research reports and the factory palette remain in the local investigation workspace; they are not required to build the app or included in the minimal release ZIP.

Run `bash build.sh` then `python3 build_nemesis_package.py` from the project root; the default ZIP is written under `dist/`. The ZIP's generated `SHA256SUMS` records its source and payload hashes. The hooks have been tested on a disposable mock filesystem; package and tile-hook changes can also be validated in the workspace emulator.
