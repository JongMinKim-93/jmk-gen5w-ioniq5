#!/system/bin/sh
# jmk-wifi, shared by the hooks. NEMESIS runs them as root with the package folder as the current directory.
# (this head unit's mksh: single-digit fds only; no sed/head/tail/printf; toolbox dd, md5, cmp, grep exist)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
# a hook started over adb runs in adbd's session: a pulled cable or a host timeout must not stop it halfway
trap '' HUP INT PIPE
PKG=/data/nemesis/apps/jmk-wifi
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-wifi
DIR=/data/local/tmp/jmk-wifi
STORE=/data/nemesis/jmk-wifi
BACKUP=/data/nemesis/backups/jmk-wifi
LOG=/data/nemesis/jmk-wifi.log

# libhardware_legacy.so of NEEV.KOR V039 260902 and the same file with patch P2 (tools/jmk-wifi/EMULATION-PLAN.md section 5):
# at 0x42d8 (17112) wifi_load_driver's "bl is_wifi_driver_loaded" becomes "movs r0,#1; nop", so the stock Wi-Fi stack
# takes the driver as loaded and never insmods/rmmods the Broadcom module this car has no chip for.
LIB=/system/lib/libhardware_legacy.so
STOCK_MD5=f81b0eb4b392bc766e0bcc1488272e0e
PATCHED_MD5=ef847b5075e01067a071c59434a9ac44
P2_OFFSET=17112

# "emulate": the dongle passes as the stock Wi-Fi module (chipless cars). "client": the car has the stock module, so the
# dongle only joins the phone hotspot and nothing stock is patched or driven. Decided by the preinstall, read at boot.
MODE_FILE=$STORE/mode
HW_FILE=$STORE/hw-install.txt   # what the preinstall saw (the USB installer copies it into its log)

log() { echo "$1"; echo "$(date) $1" >> $LOG 2>/dev/null; true; }

# The stock Wi-Fi module (Broadcom BCM89359, bcmdhd): a wlan0 that is not our dongle (while the stock Wi-Fi is on) or a
# Broadcom SDIO/PCI device (when the chip is powered). A chipless car has neither (car 2026-11-09: wlan0 -> rtl88x2bu,
# sdio bus empty). Prints what it saw; true when the module is there.
stock_module() {
    local d ven drv
    if [ -e /sys/class/net/wlan0 ]; then
        drv=$(readlink /sys/class/net/wlan0/device/driver 2>/dev/null)
        case "$drv" in
            */rtl88x2bu) ;;
            *) echo "wlan0 driven by '${drv##*/}'"; return 0 ;;
        esac
    fi
    for d in /sys/bus/sdio/devices/* /sys/bus/pci/devices/*; do
        [ -r "$d/vendor" ] || continue
        read -r ven < "$d/vendor"
        case "$ven" in
            0x02d0|0x14e4) echo "Broadcom device ${d##*/} ($ven)"; return 0 ;;
        esac
    done
    return 1
}

# Network ports with their drivers, SDIO/PCI devices, Wi-Fi modules and props: data from cars we have not seen
hw_report() {
    local n d ven dev drv
    echo "product $(getprop ro.build.product), kernel $(cat /proc/sys/kernel/osrelease)"
    for n in /sys/class/net/*; do
        [ -e "$n" ] || continue
        drv=$(readlink $n/device/driver 2>/dev/null)
        echo "net ${n##*/}: ${drv##*/}"
    done
    for d in /sys/bus/sdio/devices/* /sys/bus/pci/devices/*; do
        [ -r "$d/vendor" ] || continue
        read -r ven < "$d/vendor"; dev=; [ -r "$d/device" ] && read -r dev < "$d/device"
        echo "bus ${d##*/}: $ven $dev"
    done
    grep -E '^(bcmdhd|dhd|88x2bu|8812au|8821cu|88x2cu|8188eu) ' /proc/modules | while read -r n d rest; do echo "module $n"; done
    echo "props wlan.driver.status=$(getprop wlan.driver.status) tcc.wifi.vendor=$(getprop tcc.wifi.vendor) wifi.interface=$(getprop wifi.interface) wifi.info.channel=$(getprop wifi.info.channel)"
    # nl80211 (read only): the ports and what each radio allows next to its hotspot (1.3.0, stock-module client port)
    if [ -f bin/jmkiw ]; then
        chmod 0755 bin/jmkiw 2>/dev/null
        ./bin/jmkiw dev 2>&1
        ./bin/jmkiw phy 2>&1
    fi
}
md5of() { set -- $(md5 "$1" 2>/dev/null); echo "$1"; }

system_rw() {
    local dev mnt fs opts rest
    while read -r dev mnt fs opts rest; do
        [ "$mnt" = /system ] || continue
        case ",$opts," in *,rw,*) return 0 ;; esac
        return 1
    done < /proc/mounts
    return 1
}

# Replace the library by rename, so running processes keep the file they mapped; takes effect at the next boot.
# /system goes back to read-only if it was read-only before, whatever the remount command returned.
swap_lib() {
    local src=$1 tmp=/system/lib/.libhardware_legacy.so.jmk was_ro=0 r
    system_rw || was_ro=1
    [ $was_ro -eq 1 ] && /system/xbin/nemesis remount rw >/dev/null 2>&1
    rm -f $tmp
    cp "$src" $tmp && chmod 0644 $tmp && sync && cmp "$src" $tmp >/dev/null && mv $tmp $LIB
    r=$?
    rm -f $tmp 2>/dev/null
    sync
    if [ $was_ro -eq 1 ] && system_rw; then
        /system/xbin/nemesis remount ro >/dev/null 2>&1
        system_rw && log "WARNING: /system is still read-write"
    fi
    return $r
}

# the daemon, only if that pid still runs our class (the pid file survives reboots)
stop_daemon() {
    local pid
    [ -f "$DIR/daemon.pid" ] || return 0
    read -r pid < "$DIR/daemon.pid" || pid=
    case "$pid" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkwifi.WifiDaemon "/proc/$pid/cmdline" 2>/dev/null && kill "$pid" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
}
