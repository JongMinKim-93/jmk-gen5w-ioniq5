#!/system/bin/sh
# NEMESIS service (root): the MAP key watcher and camping daemon (jmkmap.MapDaemon). NEMESIS starts it at
# boot and right after every update; an older daemon is stopped first. After an update started from adb this runs
# as root without capabilities: the Dalvik cache therefore lives in the package (ANDROID_DATA), not /data/dalvik-cache.
# (mksh: single-digit fds only; no sed/head/tail on this firmware)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
PKG=/data/nemesis/apps/jmk-map-menu
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-map-menu
DIR=/data/local/tmp/jmk-map-menu
# started by an install from `adb shell`, this script shares that session: it was killed when the session closed
# (hangup, or writing to the gone terminal), mostly before the daemon was up (car 2026-11-10). Ignore the hangup
# (the daemon inherits that) and keep all output off the terminal.
trap '' HUP
mkdir -p "$PKG/var"
exec </dev/null >"$PKG/var/svc.log" 2>&1   # the latest start only
echo "$(date) start $$"
# the shared dir must be world-writable (the app, the uid-1000 ambient worker and this daemon all write there), and
# sticky (1777 since 2.1.0): nobody replaces or deletes another uid's file; each reader also checks whose a file is.
# /data/local/tmp is 0771 shell:shell after boot: root without capabilities can't create in it, so ask the shell user.
mkdir -p "$DIR" 2>/dev/null || /system/xbin/nemesis root 2000 -c "mkdir -p $DIR" </dev/null >/dev/null 2>&1
chmod 1777 "$DIR" 2>/dev/null || /system/xbin/nemesis root 2000 -c "chmod 1777 $DIR" </dev/null >/dev/null 2>&1
# the pid file survives a reboot (/data): only kill that pid while it is still our daemon, not whatever got the number
if [ -f "$DIR/daemon.pid" ]; then
    read -r old < "$DIR/daemon.pid" || old=
    case "$old" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkmap.MapDaemon "/proc/$old/cmdline" 2>/dev/null && kill "$old" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
fi
i=0
while [ "$(getprop sys.boot_completed)" != 1 ] && [ $i -lt 150 ]; do sleep 2; i=$((i + 1)); done
# wireless adb (taken over from the usb.mode package): adbd also on TCP 5555, accepted only on the dongle's client port
# (rtwlan*, its number moves on a replug) and lo; key auth stays on, the developer's key is in the package (adbkey.pub).
# Needs capabilities (boot); after an adb install it fails quietly and the rules from the boot stay.
if [ -s "$PKG/adbkey.pub" ]; then
    K=/data/misc/adb/adb_keys
    mkdir -p /data/misc/adb
    read -r key < "$PKG/adbkey.pub"
    { [ -f $K ] && grep -qF "$key" $K; } || echo "$key" >> $K
    chown system:shell /data/misc/adb $K
    chmod 750 /data/misc/adb
    chmod 640 $K
fi
for r in "-i lo -p tcp --dport 5555 -j ACCEPT" "-i rtwlan+ -p tcp --dport 5555 -j ACCEPT" "-p tcp --dport 5555 -j DROP"; do
    n=0
    while iptables -D INPUT $r 2>/dev/null && [ $n -lt 10 ]; do n=$((n + 1)); done
done
iptables -I INPUT -p tcp --dport 5555 -j DROP
iptables -I INPUT -i rtwlan+ -p tcp --dport 5555 -j ACCEPT
iptables -I INPUT -i lo -p tcp --dport 5555 -j ACCEPT
[ "$(getprop service.adb.tcp.port)" = 5555 ] || setprop service.adb.tcp.port 5555
[ "$(getprop init.svc.adbd)" = running ] || start adbd
mkdir -p "$PKG/var/dalvik-cache"
[ -f "$DIR/daemon.log" ] && mv "$DIR/daemon.log" "$DIR/daemon.log.old"
echo "$(date) daemon $$"
echo $$ > "$DIR/daemon.pid"
chmod 0644 "$DIR/daemon.pid"
ANDROID_DATA="$PKG/var" CLASSPATH="$PKG/bin/mapmenu.dex" exec /system/bin/app_process /system/bin jmkmap.MapDaemon \
    </dev/null >>"$DIR/daemon.log" 2>&1
