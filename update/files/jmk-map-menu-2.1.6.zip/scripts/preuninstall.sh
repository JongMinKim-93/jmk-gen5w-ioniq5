#!/system/bin/sh
# Leaves camping first (the daemon puts the screen, display and light back), stops the daemon, removes the app.
# NEMESIS runs this before every update too; postinstall puts the new APK back.
DIR=/data/local/tmp/jmk-map-menu
TARGET=/system/app/JMKMap.apk
if [ -f "$DIR/camp" ]; then
    rm -f "$DIR/camp"
    sleep 3
fi
if [ -f "$DIR/daemon.pid" ]; then
    read -r pid < "$DIR/daemon.pid" || pid=
    case "$pid" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkmap.MapDaemon "/proc/$pid/cmdline" 2>/dev/null && kill "$pid" 2>/dev/null ;;
    esac
fi
if [ -f "$TARGET" ]; then
    remounted=0
    while read -r dev mnt fs opts rest; do
        [ "$mnt" = /system ] || continue
        case ",$opts," in *,rw,*) ;; *) /system/xbin/nemesis remount rw && remounted=1 ;; esac
        break
    done < /proc/mounts
    rm -f "$TARGET"
    sync
    # /system stays read-write (a failing "remount ro" broke updates, car 2026-11-10)
fi
# 커스텀 워머창: the stock seat popup back (the intent firewall rule; the system user owns /data/system/ifw)
/system/xbin/nemesis root 1000 -c "rm -f /data/system/ifw/jmk-warmer.xml" >/dev/null 2>&1 || rm -f /data/system/ifw/jmk-warmer.xml
rm -f "$DIR/daemon.pid" "$DIR/status" "$DIR/request" "$DIR/vr" "$DIR/camp-dark" "$DIR/ifw-rule"
exit 0
