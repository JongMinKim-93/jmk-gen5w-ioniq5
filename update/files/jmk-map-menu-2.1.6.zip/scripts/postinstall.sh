#!/system/bin/sh
# Installs the menu app into /system/app, the way Ambient Sound does on this head unit: once booted, its PackageManager
# refuses user installs from non-OEM signers, and it picks up an APK placed in /system/app by itself. The daemon is
# started by the [service.0] NEMESIS runs after this hook. (mksh: single-digit fds; no sed/head/tail)
set -e
PKG=/data/nemesis/apps/jmk-map-menu
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-map-menu
TARGET=/system/app/JMKMap.apk
[ -f app/JMKMap.apk ] && [ -f bin/mapmenu.dex ] || exit 1
chmod 0755 "$PKG" "$PKG/app" "$PKG/bin" "$PKG/svc" "$PKG/scripts"
chmod 0644 "$PKG/app/JMKMap.apk" "$PKG/bin/mapmenu.dex"
remounted=0
while read -r dev mnt fs opts rest; do
    [ "$mnt" = /system ] || continue
    case ",$opts," in *,rw,*) ;; *) /system/xbin/nemesis remount rw; remounted=1 ;; esac
    break
done < /proc/mounts
# /system stays read-write: NEMESIS leaves it rw after boot on purpose, and a "remount ro" that fails (EBUSY) used to
# fail the hook, which half-removed the package on an update (car 2026-11-10).
rm -f "$TARGET.new"
cp "$PKG/app/JMKMap.apk" "$TARGET.new"
chmod 0644 "$TARGET.new"
cmp "$PKG/app/JMKMap.apk" "$TARGET.new" >/dev/null
mv "$TARGET.new" "$TARGET"
sync
remounted=0
[ "$(getprop sys.boot_completed)" = 1 ] || exit 0
# after an update this firmware may keep a stale Dalvik cache: loading a class rebuilds it (no main: exits with an error)
/system/xbin/nemesis root 1000 -c "/system/bin/dalvikvm -cp $TARGET jmkmap.MenuActivity" >/dev/null 2>&1 || true
n=0
while [ "$n" -lt 15 ]; do
    case "$(/system/bin/pm path com.jmk.map 2>/dev/null)" in *"$TARGET"*) echo 'JMK MAP menu installed: hold MAP for 1.5 s.'; exit 0 ;; esac
    sleep 1; n=$((n + 1))
done
echo 'APK in place; PackageManager has not listed it yet (a head-unit reboot will).' >&2
exit 0
