#!/system/bin/sh
# Stops the daemon and puts the stock libhardware_legacy.so back. NEMESIS runs this before every update too; the new
# postinstall patches again and the new daemon takes over the running client, so wireless adb stays up.
# Left as they are until the next boot, on purpose: the driver (never rmmod: that rebooted the head unit), the client
# (wpa_supplicant, dhcpcd, routes) and the stock hotspot. The saved networks stay in /data/nemesis/jmk-wifi.
. ./scripts/common.sh
log "preuninstall jmk-wifi"
stop_daemon
cur=$(md5of $LIB)
# Never block the uninstall: a library left patched is harmless without the dongle (the stock path then fails at the
# hotspot start instead of at the Broadcom insmod, as it always did on this chipless car).
if [ "$cur" = $PATCHED_MD5 ]; then
    if [ "$(md5of $BACKUP/libhardware_legacy.so)" != $STOCK_MD5 ]; then
        log "WARNING: stock backup missing or changed, library left patched"
    elif ! swap_lib $BACKUP/libhardware_legacy.so; then
        log "WARNING: could not restore $LIB, left patched"
    elif [ "$(md5of $LIB)" != $STOCK_MD5 ]; then
        log "WARNING: restored library is $(md5of $LIB)"
    else
        log "stock libhardware_legacy.so restored (takes effect at the next boot)"
    fi
else
    log "libhardware_legacy.so is $cur, not our patched file: left alone"
fi
rm -f "$DIR/status" "$DIR/request" "$DIR/req/request"
# a real uninstall (1.3.4): the stock Wi-Fi client setting as it was before the daemon turned it off (a car with the
# stock module gets its own Wi-Fi back at the next boot), and the installed marker goes. An update keeps both.
if real_uninstall; then
    if [ -f $WIFI_ON_BEFORE ]; then
        read -r v < $WIFI_ON_BEFORE
        case "$v" in
            0|1) settings put global wifi_on $v >/dev/null 2>&1 && log "wifi_on back to $v (as before jmk-wifi)" ;;
        esac
        rm -f $WIFI_ON_BEFORE
    fi
    rm -f $INSTALLED
fi
exit 0
