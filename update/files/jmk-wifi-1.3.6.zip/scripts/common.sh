#!/system/bin/sh
# jmk-wifi, shared by the hooks. NEMESIS runs them as root with the package folder as the current directory.
# (this head unit's mksh: single-digit fds only; no sed/head/tail/printf; toolbox dd, md5, cmp, grep exist)
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
# a hook started over adb runs in adbd's session: a pulled cable or a host timeout must not stop it halfway
trap '' HUP INT PIPE
PKG=/data/nemesis/apps/jmk-wifi
[ -d "$PKG" ] || PKG=/data/nemesis/packages/jmk-wifi
DIR=/data/local/tmp/jmk-wifi
STORE=/data/nemesis/jmk-wifi
BACKUP=/data/nemesis/backups/jmk-wifi
LOG=/data/nemesis/jmk-wifi.log

# libhardware_legacy.so of NEEV.KOR V039 260902 and the same file with patch P2 (tools/jmk-wifi/EMULATION-PLAN.md section 5):
# at 0x42d8 (17112) wifi_load_driver's "bl is_wifi_driver_loaded" becomes "movs r0,#1; nop", so the stock Wi-Fi stack
# takes the driver as loaded and never insmods/rmmods the Broadcom module this car has no chip for.
LIB=/system/lib/libhardware_legacy.so
STOCK_MD5=f81b0eb4b392bc766e0bcc1488272e0e
PATCHED_MD5=ef847b5075e01067a071c59434a9ac44
P2_OFFSET=17112

# "emulate": the dongle passes as the stock Wi-Fi module (chipless cars). "client": the car has the stock module, so the
# dongle only joins the phone hotspot and nothing stock is patched or driven. Decided by the preinstall, read at boot.
MODE_FILE=$STORE/mode
HW_FILE=$STORE/hw-install.txt   # what the preinstall saw (the USB installer copies it into its log)
# "locked" (1.3.6): why, one line (the kernel or the library did not fit); the service puts it into the status
LOCKED_FILE=$STORE/locked

log() { echo "$1"; echo "$(date) $1" >> $LOG 2>/dev/null; true; }

# There while the package is installed (1.3.4): postinstall makes it, only a real uninstall takes it away, so the
# preinstall of an update knows it is one. The wifi_on value from before the daemon first turned it off.
INSTALLED=$STORE/installed
WIFI_ON_BEFORE=$STORE/wifi_on.before

# A real uninstall, not the old package's uninstall step inside an update: NEMESIS runs the old preuninstall with the
# new package already staged (the HMG-API rule). Never "update" when the nemesis command is an uninstall: a stage left
# by an interrupted install must not turn an uninstall into nothing.
real_uninstall() {
    case "$(cat /proc/$PPID/cmdline 2>/dev/null)" in *uninstall*) return 0 ;; esac
    grep -q '^id=jmk-wifi$' /data/local/tmp/nemesis/stage/jmk-wifi/NEMESIS.data 2>/dev/null && return 1
    return 0
}

# Another Wi-Fi app on the car (the MAP menu's and the USB installer's rules, 2.1.0): a package known to bring one,
# any other package with a Wi-Fi driver (a .ko naming 80211; Leafia and ours ship none), or a USB Wi-Fi port up that
# is not our rtl88x2bu (second port rtwlan%d; it stays loaded until the next boot after our uninstall). Prints it.
other_wifi() {
    local d k n drv p2
    for d in /data/nemesis/apps/* /data/nemesis/packages/*; do
        [ -d "$d" ] || continue
        case "${d##*/}" in
            korea.projection|niro.carplay.hotspot) echo "${d##*/}"; return 0 ;;
            jmk-*) continue ;;
        esac
        for k in "$d"/*.ko "$d"/*/*.ko "$d"/*/*/*.ko "$d"/*/*/*/*.ko "$d"/*/*/*/*/*.ko; do
            [ -f "$k" ] && grep -q 80211 "$k" 2>/dev/null && { echo "${d##*/} (${k##*/})"; return 0; }
        done
    done
    for n in /sys/class/net/*; do
        [ -e "$n/wireless" ] || [ -e "$n/phy80211" ] || continue
        case "$(readlink "$n")" in */usb*) ;; *) continue ;; esac
        drv=$(readlink "$n/device/driver" 2>/dev/null); drv=${drv##*/}
        p2=; [ -r /sys/module/88x2bu/parameters/if2name ] && read -r p2 < /sys/module/88x2bu/parameters/if2name
        [ "$drv" = rtl88x2bu ] && [ "$p2" = 'rtwlan%d' ] && continue
        echo "port ${n##*/} ($drv)"; return 0
    done
    return 1
}

# The stock Wi-Fi module (Broadcom BCM89359, bcmdhd): a wlan0 that is not our dongle (while the stock Wi-Fi is on) or a
# Broadcom SDIO/PCI device (when the chip is powered). A chipless car has neither (car 2026-11-09: wlan0 -> rtl88x2bu,
# sdio bus empty). Prints what it saw; true when the module is there.
stock_module() {
    local d ven drv
    if [ -e /sys/class/net/wlan0 ]; then
        drv=$(readlink /sys/class/net/wlan0/device/driver 2>/dev/null)
        case "$drv" in
            */rtl88x2bu) ;;
            *) echo "wlan0 driven by '${drv##*/}'"; return 0 ;;
        esac
    fi
    for d in /sys/bus/sdio/devices/* /sys/bus/pci/devices/*; do
        [ -r "$d/vendor" ] || continue
        read -r ven < "$d/vendor"
        case "$ven" in
            0x02d0|0x14e4) echo "Broadcom device ${d##*/} ($ven)"; return 0 ;;
        esac
    done
    return 1
}

# Network ports with their drivers, SDIO/PCI devices, Wi-Fi modules and props: data from cars we have not seen
hw_report() {
    local n d ven dev drv
    echo "product $(getprop ro.build.product), kernel $(cat /proc/sys/kernel/osrelease)"
    for n in /sys/class/net/*; do
        [ -e "$n" ] || continue
        drv=$(readlink $n/device/driver 2>/dev/null)
        echo "net ${n##*/}: ${drv##*/}"
    done
    for d in /sys/bus/sdio/devices/* /sys/bus/pci/devices/*; do
        [ -r "$d/vendor" ] || continue
        read -r ven < "$d/vendor"; dev=; [ -r "$d/device" ] && read -r dev < "$d/device"
        echo "bus ${d##*/}: $ven $dev"
    done
    grep -E '^(bcmdhd|dhd|88x2bu|8812au|8821cu|88x2cu|8188eu) ' /proc/modules | while read -r n d rest; do echo "module $n"; done
    echo "props wlan.driver.status=$(getprop wlan.driver.status) tcc.wifi.vendor=$(getprop tcc.wifi.vendor) wifi.interface=$(getprop wifi.interface) wifi.info.channel=$(getprop wifi.info.channel)"
    # nl80211 (read only): the ports and what each radio allows next to its hotspot (1.3.0, stock-module client port)
    if [ -f bin/jmkiw ]; then
        chmod 0755 bin/jmkiw 2>/dev/null
        ./bin/jmkiw dev 2>&1
        ./bin/jmkiw phy 2>&1
    fi
}
md5of() { set -- $(md5 "$1" 2>/dev/null); echo "$1"; }

system_rw() {
    local dev mnt fs opts rest
    while read -r dev mnt fs opts rest; do
        [ "$mnt" = /system ] || continue
        case ",$opts," in *,rw,*) return 0 ;; esac
        return 1
    done < /proc/mounts
    return 1
}

# Replace the library by rename, so running processes keep the file they mapped; takes effect at the next boot.
# /system goes back to read-only if it was read-only before, whatever the remount command returned.
swap_lib() {
    local src=$1 tmp=/system/lib/.libhardware_legacy.so.jmk was_ro=0 r
    system_rw || was_ro=1
    [ $was_ro -eq 1 ] && /system/xbin/nemesis remount rw >/dev/null 2>&1
    rm -f $tmp
    cp "$src" $tmp && chmod 0644 $tmp && sync && cmp "$src" $tmp >/dev/null && mv $tmp $LIB
    r=$?
    rm -f $tmp 2>/dev/null
    sync
    if [ $was_ro -eq 1 ] && system_rw; then
        /system/xbin/nemesis remount ro >/dev/null 2>&1
        system_rw && log "WARNING: /system is still read-write"
    fi
    return $r
}

# the daemon, only if that pid still runs our class (the pid file survives reboots)
stop_daemon() {
    local pid
    [ -f "$DIR/daemon.pid" ] || return 0
    read -r pid < "$DIR/daemon.pid" || pid=
    case "$pid" in
        ''|*[!0-9]*) ;;
        *) grep -q jmkwifi.WifiDaemon "/proc/$pid/cmdline" 2>/dev/null && kill "$pid" 2>/dev/null ;;
    esac
    rm -f "$DIR/daemon.pid"
}

# A locked install tells the developer once per version, through the JMK MAP menu's outbox (sent when the head unit is
# online and reports are on; the menu adds the car's code, firmware and versions and takes MAC and IP addresses out):
# why it is locked and what the preinstall saw (hw_report), data for supporting that model. Nothing else.
locked_report() {
    local ver= l old= box=/data/local/tmp/jmk-map-menu/outbox detail at tmp
    while read -r l; do case "$l" in package-version=*) ver=${l#package-version=} ;; esac; done < "$PKG/NEMESIS.data"
    [ -r $STORE/locked-reported ] && read -r old < $STORE/locked-reported
    [ -n "$ver" ] && [ "$old" != "$ver" ] && [ -d $box ] || return 0
    detail=
    [ -r $LOCKED_FILE ] && read -r detail < $LOCKED_FILE
    case "$detail" in *'"'*|*'\'*) detail='(reason not printable)' ;; esac
    if [ -r $HW_FILE ]; then
        while read -r l; do
            case "$l" in *'"'*|*'\'*) continue ;; esac
            set -f; set -- $l; set +f   # tabs and runs of spaces become one space (no raw control characters in JSON)
            [ $# -gt 0 ] && detail="$detail / $*"
        done < $HW_FILE
    fi
    at=$(date +%s)000
    tmp=$box/.jmk-wifi-locked-$$.tmp
    echo "{\"kind\":\"jmk-report\",\"type\":\"install\",\"app\":\"jmk-wifi\",\"ver\":\"$ver\",\"msg\":\"jmk-wifi $ver locked (driver does not fit this model)\",\"detail\":\"$detail\",\"at\":$at}" > $tmp 2>/dev/null || { rm -f $tmp; return 0; }
    chmod 0644 $tmp
    mv $tmp $box/jmk-wifi-locked-$at.json && echo "$ver" > $STORE/locked-reported
    return 0
}
