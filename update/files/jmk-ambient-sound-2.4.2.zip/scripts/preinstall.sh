#!/system/bin/sh
set -e
. ./scripts/common.sh
product=$(getprop ro.product.device)
fingerprint=$(getprop ro.build.fingerprint)
if [ "$product" = wp_daudioplus_neev23se_us ] && [ "$fingerprint" = 'ecohmc/wp_daudioplus_ecohmc_us/wp_daudioplus_ecohmc_us:4.4.2/KVT49L/eng.vmadmin.20260507.094910:user/dev-keys' ]; then
    : # Verified physical head-unit profile.
elif [ "$product" = wp_daudioplus_neev_kr ] && [ "$fingerprint" = 'ecohmc/wp_daudioplus_ecohmc_kr/wp_daudioplus_ecohmc_kr:4.4.2/KVT49L/eng.vmadmin.20260902.180807:user/dev-keys' ]; then
    : # Korean NEEV 260902: SML transactions 0x4d/0x4e checked in its automotive.jar; lighting untested.
elif [ "$product" = wp_daudioplus_neev_ca ] && [ "$fingerprint" = 'ecohmc/wp_daudioplus_ecohmc_us/wp_daudioplus_ecohmc_us:4.4.2/KVT49L/eng.vmadmin.20260206.061258:user/dev-keys' ] && [ -d /sys/devices/platform/a000000.virtio_mmio ]; then
    echo 'Recognized QEMU test profile; real audio and vehicle hardware are not emulated.'
else
    echo 'Unsupported product or firmware fingerprint' >&2
    exit 1
fi
# the JMK MAP menu decides whether this version may run (2.1.1+) and updates it: it goes in first. Only on a first
# install: an update has already run the old package's uninstall hooks by now (NEMESIS is not transactional), so a
# refusal here would leave it half removed. The backups folder outlives an uninstall.
if [ ! -d "$BACKUP" ] && [ ! -d /data/nemesis/apps/jmk-map-menu ] && [ ! -d /data/nemesis/packages/jmk-map-menu ]; then
    echo 'JMK 맵핑퀵메뉴(jmk-map-menu)를 먼저 설치하세요 (install jmk-map-menu first)' >&2
    exit 1
fi
[ -f app/JMKAmbient.apk ] && [ -f bin/miclight.dex ] && [ -f bin/ambient_party_mode.sh ] || { echo 'Package payload incomplete' >&2; exit 1; }
if [ -e "$TARGET" ]; then
    if ! same_file "$TARGET" app/JMKAmbient.apk && ! same_file "$TARGET" app/JMKAmbient-approved-legacy.apk; then
        echo 'Existing JMKAmbient.apk differs from the approved build; refusing replacement' >&2
        exit 1
    fi
fi
